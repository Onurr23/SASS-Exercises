Ford Trucks F-MAX truck mod developed for Euro Truck Simulator 2. The F-MAX truck is modeled from scratch in full detail, faithful to the actual model. It was shared as a free mod for ETS 2. Developed by Emre Aydın and Bertan Baday, F-MAX truck mod published by SimülasyonTÜRK.
Ford Truck F-MAX is available from truck dealers/mod dealer.
The project in three words!
Volunteer - Detailed - Free
Version: 1.5
Please! Do not reupload.
Author: Emre Aydın, Bertan Baday, Hasan Elmaz Öfke (SimülasyonTÜRK), SiSL
version ETS2 1.36.x, 1.35.x

Steam Workshop https://steamcommunity.com/sharedfiles/filedetails/?id=1915802227
SCS Software's forum https://forum.scssoft.com/viewtopic.php?f=35&t=274617
Official Website https://fmax.simulasyonturk.com/?lang=en
Ford Trucks Dealer available on https://fmax.simulasyonturk.com/?lang=en (optional)
CREDITS

    Publisher: @simulation Hasan Elmaz Öfke – SimülasyonTÜRK
    Modelling and Textures: Bertan Baday @bertan06, Emre Aydın @Hardoux)
    Convert to game: Emre Aydın
    Blender Convertion and Tree Organization: Selcuk Islamoglu (@SiSL)
    Dashboard: @Oscar
    Sounds: Engine Voice Records ( EVR [enginevoicerecords.com] ) @Vasily EVR
    Sound record and photos for Real F-MAX: @OnurKull
    Photos for Real F-MAX: @Eugene
    Catalog Colors, FIA ETRC, Truck of the Year Paint Jobs: OnurKull
    Baltrak Lojistik Paint Jobs: SiSL (Idea of skin: UmutUzunkaş)
    Support for Turkish Paint Jobs Pack DLC: BlackMoon (BM Logistics)
    Support for European Logistics Companies Paint Jobs Pack: Ahmet Soydan (SinagritBaba) @Sinagrit_Baba
    Beta Testers: OnurKull, BlackMoon, Süleyman Fahri Kurt(SFK), Ahmet Soydan (SinagritBaba), Özkan Poyrazoğlu (feelgoodinc)
    Launch Trailer Video: Hetrix

FEATURES

    Original F-MAX Interior and Exterior
    FORD Trucks Dealer (in Berlin and optional)Not compatible with ProMods or TruckSimMap.
    Original Dashboard
    Original Sounds (Ford Cargo 1842T from EngineVoiceRecords)
    Standalone Modding
    Animated Pedals
    Animated Handbrake
    Support for Cabin Accessories
    Support for SiSL Mega Pack
    Cabin lights
    Skin Template
    Compatible with standard game features

    4x2 Normal and LL Chassis
    EcoTorq 12.7L Engine
    500 PS engine, 2500 Nm torq
    ZF 12TX2620 Gearbox, 6 and 7 gearbox
    Changeable Front Grill
    600L Main Fuel Tank + 450L Extra Fuel Tank (Optional)

FULL FEATURE LIST https://fmax.simulasyonturk.com/?lang=en 